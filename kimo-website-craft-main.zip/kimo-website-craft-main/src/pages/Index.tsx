
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Features from "@/components/Features";
import HowItWorks from "@/components/HowItWorks";
import Applications from "@/components/Applications";
import Comparison from "@/components/Comparison";
import Challenges from "@/components/Challenges";
import FutureScope from "@/components/FutureScope";
import Team from "@/components/Team";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen font-sans">
      <Navbar />
      <Hero />
      <About />
      <Features />
      <HowItWorks />
      <Applications />
      <Comparison />
      <Challenges />
      <FutureScope />
      <Team />
      <Contact />
      <Footer />
    </div>
  );
};

export default Index;
