
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="pt-24 pb-16 md:pt-32 md:pb-24 min-h-screen flex items-center">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-12 md:mb-0 md:pr-10">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-heading mb-6 animate-fade-in">
              Welcome to <span className="text-primary">THE KiMo</span>
              <br />
              <span className="text-secondary">Innovating Ideas</span> for a Smarter Future
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 animate-fade-in" style={{ animationDelay: "0.2s" }}>
              Transforming concepts into solutions with precision and creativity.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                Learn More
              </Button>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/10">
                Get Started
              </Button>
              <Button size="lg" variant="ghost" className="text-primary hover:bg-primary/10">
                Contact Us
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center animate-fade-in" style={{ animationDelay: "0.5s" }}>
            <div className="relative">
              <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary/10 rounded-full filter blur-xl animate-pulse-slow"></div>
              <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-secondary/10 rounded-full filter blur-xl animate-pulse-slow" style={{ animationDelay: "1s" }}></div>
              <div className="bg-gradient-to-br from-primary/80 to-secondary/80 rounded-2xl p-1">
                <div className="bg-white rounded-2xl p-8 backdrop-blur-sm">
                  <img 
                    src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=600&h=600" 
                    alt="Innovation Concept" 
                    className="rounded-xl w-full h-auto object-cover shadow-lg animate-float" 
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
