
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";

const Applications = () => {
  const applications = [
    {
      title: "Business Process Optimization",
      description: "Streamline operations and eliminate inefficiencies to boost productivity and reduce costs.",
      icon: "💼",
      color: "from-blue-500 to-blue-700"
    },
    {
      title: "Education and Training Modules",
      description: "Create engaging, effective learning experiences with customized training solutions.",
      icon: "🎓",
      color: "from-green-500 to-green-700"
    },
    {
      title: "Product Development & Design",
      description: "Accelerate innovation cycles and create better products with our methodology.",
      icon: "🛠️",
      color: "from-amber-500 to-amber-700"
    },
    {
      title: "Marketing and Strategic Planning",
      description: "Develop data-driven strategies that connect with your target audience and drive results.",
      icon: "📊",
      color: "from-purple-500 to-purple-700"
    },
    {
      title: "Technology Integration",
      description: "Seamlessly incorporate new technologies into your existing infrastructure.",
      icon: "🔌",
      color: "from-rose-500 to-rose-700"
    }
  ];

  return (
    <section id="applications" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            Applications of <span className="text-primary">KiMo</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            How our solution excels across different industries and scenarios
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {applications.map((app, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className={`bg-gradient-to-r ${app.color} h-2`}></div>
              <div className="p-6">
                <div className="text-3xl mb-4">{app.icon}</div>
                <h3 className="text-xl font-bold mb-3">{app.title}</h3>
                <p className="text-muted-foreground">{app.description}</p>
                <Button variant="ghost" className="mt-4 inline-flex items-center text-primary hover:text-primary/80 p-0">
                  Learn more <ChevronRight className="ml-1 w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16">
          <div className="bg-slate-50 rounded-2xl p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-2/3 mb-8 md:mb-0">
                <h3 className="text-2xl md:text-3xl font-bold mb-4">
                  Need a custom application?
                </h3>
                <p className="text-lg text-muted-foreground">
                  Our team can develop tailored solutions for your specific industry requirements.
                  Contact us to discuss how KiMo can be adapted to your unique challenges.
                </p>
              </div>
              <div className="md:w-1/3 md:pl-8 flex justify-center">
                <Button size="lg" className="bg-primary hover:bg-primary/90">
                  Request a Consultation
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Applications;
