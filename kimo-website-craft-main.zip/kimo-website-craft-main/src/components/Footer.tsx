
import { ArrowUp, Mail, Phone } from "lucide-react";

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <footer className="bg-slate-900 text-slate-200">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <h3 className="text-2xl font-bold text-white mb-4">THE KiMo</h3>
            <p className="mb-6">
              Innovating ideas for a smarter future. Transforming concepts into solutions with precision and creativity.
            </p>
            <div className="flex space-x-3">
              {['twitter', 'facebook', 'linkedin', 'instagram'].map((social) => (
                <a 
                  key={social}
                  href="#" 
                  className="w-9 h-9 rounded-full flex items-center justify-center bg-slate-800 hover:bg-primary transition-colors"
                >
                  <span className="sr-only">{social}</span>
                  <div className="w-4 h-4 flex items-center justify-center">
                    {/* Social icon placeholder */}
                    <div className="w-3 h-3 bg-current rounded-sm"></div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { name: "About KiMo", href: "#about" },
                { name: "Features", href: "#features" },
                { name: "How It Works", href: "#how-it-works" },
                { name: "Applications", href: "#applications" },
                { name: "Future Scope", href: "#future-scope" },
                { name: "Contact Us", href: "#contact" }
              ].map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="hover:text-primary transition-colors inline-block"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Contact Info</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Mail className="w-5 h-5 text-primary mt-0.5 mr-3" />
                <div>
                  <p>contact@thekimo.com</p>
                  <p>support@thekimo.com</p>
                </div>
              </li>
              <li className="flex items-start">
                <Phone className="w-5 h-5 text-primary mt-0.5 mr-3" />
                <div>
                  <p>+1 902-321-6295</p>
                  <p>Monday-Friday, 9am-5pm EST</p>
                </div>
              </li>
              <li>
                <address className="not-italic">
                  123 Innovation Street<br />
                  Tech District, Innovation City<br />
                  IN 10101
                </address>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Newsletter</h4>
            <p className="mb-4">
              Subscribe to our newsletter to receive updates and insights.
            </p>
            <div className="flex flex-col space-y-3">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="bg-slate-800 border border-slate-700 rounded-md px-4 py-2 text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button className="bg-primary hover:bg-primary/90 text-white font-semibold py-2 px-4 rounded-md transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} THE KiMo. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-primary transition-colors">Sitemap</a>
          </div>
        </div>
      </div>

      <button 
        onClick={scrollToTop}
        className="fixed right-6 bottom-6 bg-primary/90 hover:bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-colors"
        aria-label="Scroll to top"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  );
};

export default Footer;
