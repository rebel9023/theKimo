
import { ArrowRight } from "lucide-react";

const About = () => {
  return (
    <section id="about" className="py-16 md:py-24 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            What is <span className="text-primary">KiMo</span>?
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto"></div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <div className="relative max-w-md mx-auto md:mr-0">
              <div className="absolute -top-5 -left-5 h-full w-full rounded-2xl border-2 border-primary/30"></div>
              <div className="absolute -bottom-5 -right-5 h-full w-full rounded-2xl border-2 border-secondary/30"></div>
              <div className="relative bg-white p-6 rounded-2xl shadow-lg">
                <p className="text-lg mb-4">
                  <span className="font-bold text-primary">THE KiMo</span> is more than just an idea — it's a dynamic approach to solving modern challenges using innovative methodologies and practical applications.
                </p>
                <p className="text-lg mb-6">
                  Built for industries, businesses, and creators looking for cutting-edge solutions, KiMo combines efficiency, creativity, and scalability.
                </p>
                <div className="flex items-center text-primary font-semibold hover:text-secondary transition-colors cursor-pointer group">
                  <span>Discover our mission</span>
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          </div>
          
          <div className="md:w-1/2 md:pl-16">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                {
                  title: "Innovation",
                  description: "Pioneering new approaches to common challenges",
                  icon: "🚀",
                  delay: 0
                },
                {
                  title: "Efficiency",
                  description: "Optimizing processes for maximum productivity",
                  icon: "⚡",
                  delay: 0.1
                },
                {
                  title: "Adaptability",
                  description: "Flexible solutions for evolving needs",
                  icon: "🔄",
                  delay: 0.2
                },
                {
                  title: "Scalability",
                  description: "Solutions that grow with your business",
                  icon: "📈",
                  delay: 0.3
                }
              ].map((item, index) => (
                <div 
                  key={index}
                  className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow animate-fade-in"
                  style={{ animationDelay: `${item.delay}s` }}
                >
                  <div className="text-3xl mb-3">{item.icon}</div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
