
import { Cpu, Globe, Lightbulb, LineChart, Rocket } from "lucide-react";

const FutureScope = () => {
  const futureInitiatives = [
    {
      title: "AI Integration",
      description: "Incorporating artificial intelligence to enhance decision-making capabilities",
      icon: <Cpu className="w-10 h-10 text-primary" />,
    },
    {
      title: "Global Expansion",
      description: "Scaling our impact to serve more industries worldwide",
      icon: <Globe className="w-10 h-10 text-primary" />,
    },
    {
      title: "Research Partnerships",
      description: "Collaborating with academic institutions to push innovation boundaries",
      icon: <Lightbulb className="w-10 h-10 text-primary" />,
    },
    {
      title: "Advanced Analytics",
      description: "Developing deeper insights through enhanced data processing",
      icon: <LineChart className="w-10 h-10 text-primary" />,
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            Shaping Tomorrow with <span className="text-primary">KiMo</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            The future of KiMo lies in continuous innovation and expanding our impact
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mt-6"></div>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="lg:w-1/2">
            <div className="relative">
              <div className="absolute -z-10 top-0 right-0 w-72 h-72 bg-primary/5 rounded-full filter blur-3xl animate-pulse-slow"></div>
              <div className="relative bg-white p-8 rounded-2xl shadow-lg border border-gray-100 animate-fade-in">
                <div className="flex items-center space-x-4 mb-6">
                  <Rocket className="w-8 h-8 text-primary" />
                  <h3 className="text-2xl font-bold">Our Vision</h3>
                </div>
                <p className="text-lg mb-6">
                  The future of KiMo is centered around continuous innovation, AI-integration, 
                  and expanding our impact across global industries. Our research and development 
                  team is constantly working on the next generation of solutions.
                </p>
                <p className="text-lg mb-6">
                  We're committed to pushing the boundaries of what's possible while maintaining 
                  our core principles of adaptability, efficiency, and practical application.
                </p>
                <div className="bg-slate-50 p-4 rounded-xl border border-gray-100">
                  <p className="text-primary font-semibold">
                    "Our mission is to make advanced methodologies accessible and practical for organizations of all sizes."
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {futureInitiatives.map((item, index) => (
                <div 
                  key={index} 
                  className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="mb-4">{item.icon}</div>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>

            <div className="mt-6 bg-gradient-to-r from-primary/20 to-secondary/20 p-6 rounded-xl animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <h3 className="text-xl font-bold mb-2">Join Our Innovation Journey</h3>
              <p className="mb-4">
                Stay updated with our latest developments and be the first to access new features.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex h-10 rounded-md border border-input bg-white px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 flex-1"
                />
                <button className="bg-primary hover:bg-primary/90 text-white font-semibold py-2 px-6 rounded-md transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FutureScope;
