
import { Check } from "lucide-react";

const Features = () => {
  const features = [
    {
      title: "Versatile & Adaptable",
      description: "Works seamlessly across various industries and applications.",
      icon: "🔄",
    },
    {
      title: "Practical Solutions",
      description: "Focused on solving real-world challenges with tangible results.",
      icon: "💡",
    },
    {
      title: "Efficient & Accurate",
      description: "Optimized for performance with precision at its core.",
      icon: "⚡",
    },
    {
      title: "Future-Ready",
      description: "Built with scalability and emerging technologies in mind.",
      icon: "🚀",
    },
    {
      title: "Collaborative Growth",
      description: "Supports knowledge sharing and team development.",
      icon: "🤝",
    },
    {
      title: "Continuous Innovation",
      description: "Always evolving to meet new challenges and opportunities.",
      icon: "🔍",
    },
  ];

  return (
    <section id="features" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            Key Features of <span className="text-primary">KiMo</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Why businesses and creators choose our innovative solution
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-all hover:translate-y-[-5px] animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="text-3xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground mb-4">{feature.description}</p>
              <div className="flex items-center text-primary font-medium">
                <Check className="w-4 h-4 mr-2" />
                <span>Industry verified</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 bg-gradient-to-r from-primary to-secondary p-1 rounded-2xl animate-scale-in">
          <div className="bg-white p-8 rounded-2xl">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-2/3 mb-6 md:mb-0 md:pr-8">
                <h3 className="text-2xl font-bold mb-4">Ready to transform your approach?</h3>
                <p className="text-lg text-muted-foreground">
                  Join the growing community of businesses leveraging KiMo's innovative features
                  to solve complex challenges and drive growth.
                </p>
              </div>
              <div className="md:w-1/3 flex justify-center">
                <button className="bg-gradient-to-r from-primary to-secondary text-white font-bold py-3 px-8 rounded-full hover:opacity-90 transition-opacity">
                  Get Started Today
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
