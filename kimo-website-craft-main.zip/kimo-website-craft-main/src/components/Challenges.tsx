
import { AlertCircle, CheckCircle } from "lucide-react";

const Challenges = () => {
  const challenges = [
    {
      challenge: "Integration Complexity",
      solution: "Seamless API-based architecture designed for compatibility",
      icon: "🔄"
    },
    {
      challenge: "Learning Curve",
      solution: "Intuitive interface with comprehensive documentation and support",
      icon: "📚"
    },
    {
      challenge: "Data Management",
      solution: "Secure, scalable data handling with privacy-first approach",
      icon: "🔒"
    },
    {
      challenge: "Workflow Disruption",
      solution: "Phase-based implementation minimizing operational impact",
      icon: "⚙️"
    }
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            Facing Challenges Head-On
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We recognize the hurdles of implementing new systems and have developed effective solutions
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {challenges.map((item, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-start">
                <div className="text-3xl mr-4 mt-1">{item.icon}</div>
                <div>
                  <div className="flex items-center mb-4">
                    <AlertCircle className="w-5 h-5 text-amber-500 mr-2" />
                    <h3 className="text-xl font-bold">Challenge: {item.challenge}</h3>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                    <p className="text-lg">Solution: {item.solution}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-slate-100 rounded-2xl p-8 md:p-10 animate-fade-in">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-2/3 mb-8 md:mb-0">
              <h3 className="text-2xl font-bold mb-4">Our Adaptive Approach</h3>
              <p className="text-lg text-muted-foreground mb-4">
                KiMo's framework ensures smooth transitions and ongoing support throughout the implementation process.
                We work closely with your team to identify potential obstacles before they become problems.
              </p>
              <ul className="space-y-2">
                {[
                  "Personalized onboarding and training",
                  "Dedicated technical support",
                  "Regular optimization reviews",
                  "Flexible adaptation to feedback"
                ].map((item, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="w-4 h-4 text-primary mr-2" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="md:w-1/3 md:pl-10">
              <div className="bg-white p-6 rounded-xl shadow-md border border-gray-200">
                <h4 className="text-lg font-semibold mb-3 text-primary">Success Rate</h4>
                <div className="relative pt-1">
                  <div className="flex mb-2 items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-primary bg-primary/10">
                        Implementation Success
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-semibold inline-block text-primary">
                        98%
                      </span>
                    </div>
                  </div>
                  <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style={{ width: "98%" }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary"></div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mt-4">
                  Based on over 200+ successful implementations across various industries and organization sizes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Challenges;
