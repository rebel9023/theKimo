
const Comparison = () => {
  const comparisonData = [
    {
      feature: "Flexibility",
      kimo: "High",
      traditional: "Medium",
      kimoDescription: "Adapts to changing requirements with minimal friction",
      traditionalDescription: "Can adjust but often requires significant reconfiguration"
    },
    {
      feature: "Cost Efficiency",
      kimo: "Optimized",
      traditional: "Often Expensive",
      kimoDescription: "Pay only for what you need with predictable pricing",
      traditionalDescription: "High upfront costs with unpredictable maintenance"
    },
    {
      feature: "Scalability",
      kimo: "Easy to Scale",
      traditional: "Limited",
      kimoDescription: "Grows seamlessly with your business needs",
      traditionalDescription: "Scaling often requires complete system overhauls"
    },
    {
      feature: "Adaptability",
      kimo: "Dynamic",
      traditional: "Static",
      kimoDescription: "Rapidly adjusts to new market conditions",
      traditionalDescription: "Slow to adapt to changing requirements"
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            <span className="text-primary">KiMo</span> vs. Traditional Methods
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            See how our innovative approach compares to conventional solutions
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mt-6"></div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full bg-white rounded-xl shadow-sm border border-gray-100 animate-fade-in">
            <thead>
              <tr className="bg-slate-100">
                <th className="text-left py-4 px-6 border-b border-gray-200 font-bold">Feature</th>
                <th className="text-left py-4 px-6 border-b border-gray-200 font-bold text-primary">KiMo</th>
                <th className="text-left py-4 px-6 border-b border-gray-200 font-bold">Traditional Solutions</th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.map((item, index) => (
                <tr key={index} className="hover:bg-slate-50">
                  <td className="py-4 px-6 border-b border-gray-200 font-medium">{item.feature}</td>
                  <td className="py-4 px-6 border-b border-gray-200">
                    <div className="flex items-center">
                      <span className="inline-block bg-primary/10 text-primary font-semibold px-3 py-1 rounded-full text-sm mr-3">
                        {item.kimo}
                      </span>
                      <span className="text-sm text-gray-600">{item.kimoDescription}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 border-b border-gray-200">
                    <div className="flex items-center">
                      <span className="inline-block bg-gray-100 text-gray-700 font-semibold px-3 py-1 rounded-full text-sm mr-3">
                        {item.traditional}
                      </span>
                      <span className="text-sm text-gray-600">{item.traditionalDescription}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-12 text-center">
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-6">
            The numbers speak for themselves. KiMo consistently outperforms traditional methodologies 
            across key metrics that matter most to businesses and organizations.
          </p>
          <button className="inline-block bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-8 rounded-full transition-colors">
            See Detailed Comparison
          </button>
        </div>
      </div>
    </section>
  );
};

export default Comparison;
