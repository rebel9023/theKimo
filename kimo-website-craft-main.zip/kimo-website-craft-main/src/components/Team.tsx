
import { Github, Linkedin, Twitter } from "lucide-react";

const Team = () => {
  const teamMembers = [
    {
      name: "Pratish Pranjal Kumar",
      role: "Founder",
      bio: "Visionary leader driving innovation and strategic growth at THE KiMo.",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#"
      }
    },
    {
      name: "Kamal Singh",
      role: "Founder",
      bio: "Strategic thinker focused on developing sustainable solutions for tomorrow.",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#"
      }
    },
    {
      name: "Netri Rana",
      role: "Co-founder",
      bio: "Innovation expert specializing in transformative technology solutions.",
      social: {
        twitter: "#",
        linkedin: "#",
        github: "#"
      }
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-slate-50" id="team">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            Meet Our Team
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            The innovative minds behind KiMo's success
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl shadow-sm overflow-hidden hover-card"
            >
              <div className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-1">{member.name}</h3>
                <p className="text-primary font-medium mb-4">{member.role}</p>
                <p className="text-muted-foreground mb-4">{member.bio}</p>
                <div className="flex space-x-3">
                  <a 
                    href={member.social.twitter} 
                    className="w-9 h-9 rounded-full flex items-center justify-center border border-gray-200 text-muted-foreground hover:bg-primary hover:text-white hover:border-primary transition-colors"
                  >
                    <Twitter className="w-4 h-4" />
                  </a>
                  <a 
                    href={member.social.linkedin} 
                    className="w-9 h-9 rounded-full flex items-center justify-center border border-gray-200 text-muted-foreground hover:bg-primary hover:text-white hover:border-primary transition-colors"
                  >
                    <Linkedin className="w-4 h-4" />
                  </a>
                  <a 
                    href={member.social.github} 
                    className="w-9 h-9 rounded-full flex items-center justify-center border border-gray-200 text-muted-foreground hover:bg-primary hover:text-white hover:border-primary transition-colors"
                  >
                    <Github className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <blockquote className="text-lg italic text-muted-foreground max-w-3xl mx-auto mb-8 px-4">
            "In the eyes of darkness, we find our brightest light. Every child deserves the chance to dream, learn, and grow - regardless of their abilities."
          </blockquote>
        </div>
      </div>
    </section>
  );
};

export default Team;
