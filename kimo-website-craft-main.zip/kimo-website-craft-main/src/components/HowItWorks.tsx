
import { ArrowRight } from "lucide-react";

const HowItWorks = () => {
  const steps = [
    {
      number: "01",
      title: "Problem Identification",
      description: "We thoroughly analyze your specific challenges and requirements to understand the core issues.",
      icon: "🔍"
    },
    {
      number: "02",
      title: "Strategic Planning",
      description: "Our team develops a tailored roadmap aligned with your goals and business objectives.",
      icon: "📋"
    },
    {
      number: "03",
      title: "Solution Design",
      description: "We craft innovative solutions using best practices and cutting-edge methodologies.",
      icon: "✏️"
    },
    {
      number: "04",
      title: "Implementation",
      description: "The solution is deployed seamlessly with minimal disruption to your operations.",
      icon: "🚀"
    },
    {
      number: "05",
      title: "Review & Optimization",
      description: "Continuous monitoring and refinement ensure optimal performance and results.",
      icon: "📈"
    }
  ];

  return (
    <section id="how-it-works" className="py-16 md:py-24 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">
            <span className="text-primary">KiMo</span> Workflow
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From brainstorming to execution, we follow a clear, actionable roadmap
          </p>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mt-6"></div>
        </div>

        <div className="relative">
          {/* Progress line */}
          <div className="absolute top-0 bottom-0 left-1/2 w-1 bg-gray-200 transform -translate-x-1/2 hidden md:block"></div>
          
          {/* Steps */}
          {steps.map((step, index) => (
            <div 
              key={index} 
              className={`relative flex flex-col md:flex-row items-center mb-12 md:mb-24 last:mb-0 animate-fade-in`}
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              {/* Step number circle */}
              <div className="absolute left-1/2 transform -translate-x-1/2 z-10 w-12 h-12 bg-white rounded-full border-4 border-primary flex items-center justify-center font-bold text-primary md:left-auto md:static md:transform-none md:mr-8 md:order-1">
                {step.number}
              </div>
              
              {/* Content box */}
              <div className={`bg-white p-6 rounded-xl shadow-sm border border-gray-100 w-full md:w-5/12 mt-6 md:mt-0 text-center md:text-left ${
                index % 2 === 0 ? 'md:order-0' : 'md:order-2'
              }`}>
                <div className="text-3xl mb-3">{step.icon}</div>
                <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
              
              {/* Spacer for even steps */}
              {index % 2 === 0 ? (
                <div className="hidden md:block md:w-5/12 md:order-2"></div>
              ) : (
                <div className="hidden md:block md:w-5/12 md:order-0"></div>
              )}
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <button className="inline-flex items-center text-primary hover:text-secondary transition-colors font-semibold text-lg group">
            <span>Learn more about our process</span>
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
